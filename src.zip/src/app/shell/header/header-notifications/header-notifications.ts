import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  HostListener,
  inject,
  output,
  signal,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router } from '@angular/router';
import { catchError, filter, finalize, forkJoin, of, switchMap } from 'rxjs';

import { AuthService } from '../../../features/auth/services/auth.service';
import { Notification } from '../../../features/finance/models/notification';
import { NotificationService } from '../../../features/finance/services/notification.service';
import { TransactionService } from '../../../features/finance/services/transaction.service';
import { NotificationPanel } from './notification-panel/notification-panel';

@Component({
  selector: 'app-header-notifications',
  imports: [NotificationPanel],
  templateUrl: './header-notifications.html',
  styleUrl: './header-notifications.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderNotifications {
  private readonly authService = inject(AuthService);
  private readonly notificationService = inject(NotificationService);
  private readonly transactionService = inject(TransactionService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);

  private readonly notificationWrapper = viewChild<ElementRef<HTMLElement>>('notificationWrapper');

  readonly notificationsOpened = output<void>();

  protected readonly notifications = signal<Notification[]>([]);
  protected readonly isNotificationPanelOpen = signal(false);
  protected readonly isLoadingNotifications = signal(false);

  protected readonly unreadNotificationCount = computed(
    () => this.notifications().filter((notification) => !notification.isRead).length,
  );

  constructor() {
    this.router.events
      .pipe(
        filter((event): event is NavigationEnd => event instanceof NavigationEnd),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe(() => {
        this.closeNotificationPanel();
        this.loadNotifications();
      });

    this.transactionService.transactionsChanged$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.loadNotifications();
      });

    this.loadNotifications();
  }

  @HostListener('document:click', ['$event'])
  protected handleDocumentClick(event: MouseEvent): void {
    const target = event.target;

    if (!(target instanceof Node)) {
      return;
    }

    if (this.isNotificationPanelOpen()) {
      const notificationElement = this.notificationWrapper()?.nativeElement;

      if (notificationElement && !notificationElement.contains(target)) {
        this.closeNotificationPanel();
      }
    }
  }

  @HostListener('document:keydown.escape')
  protected handleEscapeKey(): void {
    this.closeNotificationPanel();
  }

  protected toggleNotificationPanel(): void {
    const willOpen = !this.isNotificationPanelOpen();

    if (willOpen) {
      this.notificationsOpened.emit();
    }

    this.isNotificationPanelOpen.set(willOpen);

    if (willOpen) {
      this.loadNotifications();
    }
  }

  public closeNotificationPanel(): void {
    this.isNotificationPanelOpen.set(false);
  }

  protected handleNotificationSelected(notification: Notification): void {
    if (notification.isRead) {
      this.openNotificationDestination(notification);
      return;
    }

    this.notificationService
      .markAsRead(notification.id)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updatedNotification) => {
          this.updateNotification(updatedNotification);
          this.openNotificationDestination(updatedNotification);
        },
        error: () => {
          this.openNotificationDestination(notification);
        },
      });
  }

  protected markAllNotificationsAsRead(): void {
    const unreadNotifications = this.notifications().filter((notification) => !notification.isRead);

    if (unreadNotifications.length === 0) {
      return;
    }

    forkJoin(
      unreadNotifications.map((notification) =>
        this.notificationService.markAsRead(notification.id),
      ),
    )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (updatedNotifications) => {
          const updatedById = new Map(
            updatedNotifications.map((notification) => [notification.id, notification]),
          );

          this.notifications.update((notifications) =>
            notifications.map((notification) => updatedById.get(notification.id) ?? notification),
          );
        },
      });
  }

  private loadNotifications(): void {
    const userId = this.authService.currentUser()?.id;

    if (!userId) {
      this.notifications.set([]);
      return;
    }

    this.isLoadingNotifications.set(true);

    this.notificationService
      .syncBudgetNotifications(userId, this.getCurrentMonthKey())
      .pipe(
        catchError(() => of([])),
        switchMap(() => this.notificationService.getNotifications(userId)),
        takeUntilDestroyed(this.destroyRef),
        finalize(() => this.isLoadingNotifications.set(false)),
      )
      .subscribe({
        next: (notifications) => {
          this.notifications.set(notifications);
        },
        error: () => {
          this.notifications.set([]);
        },
      });
  }

  private updateNotification(updatedNotification: Notification): void {
    this.notifications.update((notifications) =>
      notifications.map((notification) =>
        notification.id === updatedNotification.id ? updatedNotification : notification,
      ),
    );
  }

  private openNotificationDestination(notification: Notification): void {
    this.closeNotificationPanel();

    if (notification.type === 'savingsGoal') {
      void this.router.navigate(['/overview']);
      return;
    }

    void this.router.navigate(['/budgets']);
  }

  private getCurrentMonthKey(): string {
    const currentDate = new Date();

    return `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;
  }
}
